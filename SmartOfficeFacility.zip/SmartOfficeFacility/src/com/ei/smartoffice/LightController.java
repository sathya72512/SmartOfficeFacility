package com.ei.smartoffice;

public class LightController implements Observer {
    private int roomId;

    public LightController(int roomId) {
        this.roomId = roomId;
    }

    @Override
    public void update(String message) {
        System.out.println("[Light Controller] Room " + roomId + " -> " + message);
    }
}
