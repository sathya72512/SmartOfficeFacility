package com.ei.smartoffice;

public class CommandExecutor {
    public void executeCommand(Command command) {
        command.execute();
    }
}
