package com.ei.smartoffice;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        OfficeManager manager = OfficeManager.getInstance();
        manager.configureRooms(2); // configure 2 rooms

        // Add observers to each room
        try {
            Room room1 = manager.getRoom(1);
            room1.addObserver(new ACController(1));
            room1.addObserver(new LightController(1));

            Room room2 = manager.getRoom(2);
            room2.addObserver(new ACController(2));
            room2.addObserver(new LightController(2));
        } catch (InvalidRoomException e) {
            System.out.println(e.getMessage());
        }

        CommandExecutor executor = new CommandExecutor();
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Smart Office Facility ===");
        System.out.println("Commands:");
        System.out.println(" book <roomId>");
        System.out.println(" cancel <roomId>");
        System.out.println(" add <roomId> <count>");
        System.out.println(" remove <roomId>");
        System.out.println(" exit");

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();
            String[] parts = input.split(" ");

            if (parts[0].equalsIgnoreCase("exit")) {
                System.out.println("Exiting system...");
                break;
            }

            try {
                String command = parts[0];
                int roomId = Integer.parseInt(parts[1]);
                Room room = manager.getRoom(roomId); // may throw InvalidRoomException

                switch (command.toLowerCase()) {
                    case "book":
                        executor.executeCommand(new BookRoomCommand(room));
                        break;
                    case "cancel":
                        executor.executeCommand(new CancelRoomCommand(room));
                        break;
                    case "add":
                        int count = Integer.parseInt(parts[2]);
                        executor.executeCommand(new AddOccupantCommand(room, count));
                        break;
                    case "remove":
                        executor.executeCommand(new RemoveOccupantsCommand(room));
                        break;
                    default:
                        System.out.println("Unknown command!");
                }
            } catch (InvalidRoomException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Invalid input! Please try again.");
            }
        }

        scanner.close();
    }
}
