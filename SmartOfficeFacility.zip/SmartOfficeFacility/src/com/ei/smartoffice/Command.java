package com.ei.smartoffice;

public interface Command {
    void execute();
}
