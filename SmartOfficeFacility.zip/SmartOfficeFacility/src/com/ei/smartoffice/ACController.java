package com.ei.smartoffice;

public class ACController implements Observer {
    private int roomId;

    public ACController(int roomId) {
        this.roomId = roomId;
    }

    @Override
    public void update(String message) {
        System.out.println("[AC Controller] Room " + roomId + " -> " + message);
    }
}
