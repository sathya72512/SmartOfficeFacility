package com.ei.smartoffice;

public class BookRoomCommand implements Command {
    private Room room;

    public BookRoomCommand(Room room) {
        this.room = room;
    }

    @Override
    public void execute() {
        room.book();
    }
}
