package com.ei.smartoffice;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class OfficeManager {
    private static OfficeManager instance;
    private List<Room> rooms;

    // Scheduler (future use)
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    // Private constructor (Singleton)
    private OfficeManager() {
        rooms = new ArrayList<>();
    }

    // Singleton access
    public static OfficeManager getInstance() {
        if (instance == null) {
            instance = new OfficeManager();
        }
        return instance;
    }

    // Configure rooms
    public void configureRooms(int numberOfRooms) {
        rooms.clear();
        for (int i = 1; i <= numberOfRooms; i++) {
            rooms.add(new Room(i, 10)); // default capacity = 10
        }
        // Print only (no logger)
        System.out.println("Office configured with " + numberOfRooms + " rooms.");
    }

    // Get room by ID with exception handling
    public Room getRoom(int id) throws InvalidRoomException {
        if (id <= 0 || id > rooms.size()) {
            throw new InvalidRoomException("Invalid room id: " + id);
        }
        return rooms.get(id - 1);
    }
}
