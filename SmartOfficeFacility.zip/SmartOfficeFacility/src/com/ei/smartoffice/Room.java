package com.ei.smartoffice;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Room {
    private int id;
    private int capacity;
    private boolean booked;
    private int occupantsCount;

    // Observer list
    private List<Observer> observers = new ArrayList<>();

    // Scheduler for auto-release
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public Room(int id, int capacity) {
        this.id = id;
        this.capacity = capacity;
        this.booked = false;
        this.occupantsCount = 0;
    }

    public int getId() {
        return id;
    }

    public boolean isBooked() {
        return booked;
    }

    // Booking with auto release
    public void book() {
        if (!booked) {
            booked = true;
            System.out.println("Room " + id + " booked successfully.");

            // Auto release after 10 seconds (for demo).
            // In real case: use 5 MINUTES.
            scheduler.schedule(() -> {
                if (booked && occupantsCount == 0) {
                    booked = false;
                    System.out.println("Room " + id + " auto-released (no occupants).");
                }
            }, 10, TimeUnit.SECONDS);

        } else {
            System.out.println("Room " + id + " is already booked!");
        }
    }

    public void cancelBooking() {
        if (booked) {
            booked = false;
            System.out.println("Booking for Room " + id + " cancelled.");
        } else {
            System.out.println("Room " + id + " is not booked.");
        }
    }

    // Observer add
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    // Notify observers
    private void notifyObservers(String message) {
        for (Observer o : observers) {
            o.update(message);
        }
    }

    public void addOccupants(int count) {
        occupantsCount += count;
        System.out.println("Room " + id + " now has " + occupantsCount + " occupants.");

        if (occupantsCount >= 2) {
            notifyObservers("AC and Lights turned ON.");
        }
    }

    public void removeOccupants() {
        occupantsCount = 0;
        System.out.println("Room " + id + " is now empty.");
        notifyObservers("AC and Lights turned OFF.");
    }
}
