package com.ei.smartoffice;

public class RemoveOccupantsCommand implements Command {
    private Room room;

    public RemoveOccupantsCommand(Room room) {
        this.room = room;
    }

    @Override
    public void execute() {
        room.removeOccupants();
    }
}
