package com.ei.smartoffice;

public interface Observer {
    void update(String message);
}
